<?
return array(
'host' => 'sohan.mysql.ukraine.com.ua',
'login' => 'sohan_test2',
'password' => '9fw6zpy5',
'db' => 'sohan_test2'
);
?>